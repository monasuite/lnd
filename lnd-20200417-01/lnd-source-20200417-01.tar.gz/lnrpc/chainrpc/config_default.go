// +build !chainrpc

package chainrpc

// Config is empty for non-chainrpc builds.
type Config struct{}
